package University;

public class Lecturer extends ResearchAssociate {
    public Lecturer () {
    }
}