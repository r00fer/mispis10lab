# MISPISIT-10lab
![image](https://github.com/user-attachments/assets/822c1232-f689-4169-8541-85ebd13e2775)
![image](https://github.com/user-attachments/assets/2ad452cf-3dda-45c3-a485-670a92af1df7)
![image](https://github.com/user-attachments/assets/de6bba9b-8fb9-4df5-b0a5-45f7d5681ab0)
![image](https://github.com/user-attachments/assets/e10169e0-4d62-4aea-b221-713aded3e96b)
